principia.sty - a LaTeX2e package for typesetting the "Peanese" notation of Whitehead and Russell's 1910 "Principia Mathematica".

The file principia.sty is the original work of Landon D. C. Elkind (Copyright (c) 2020). It is released under the LaTeX Project Public License 1.3c.

This is principia package Version 1.0. It covers typesetting the notations through Volume I of "Principia Mathematica". See the file principia.pdf for information on how to typeset these symbols in LaTeX. 

Updates to include all notations throughout Volumes II and III are planned. Further information and updates can be found at https://logicalatomist.github.io/principia/

Comments and suggestions are welcomed by the package maintainer, signed below.

Landon D. C. Elkind 
University of Alberta